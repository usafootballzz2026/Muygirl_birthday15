// Relaxing ambient background music engine using Web Audio API
// Warm dreamy chords (Fmaj7 -> Cmaj7 -> Dm9 -> Bbmaj7) with soft low-pass filter and gentle echo

interface AmbientEngine {
  ctx: AudioContext;
  masterGain: GainNode;
  filter: BiquadFilterNode;
  chordTimer: number | null;
  melodyTimer: number | null;
  isPlaying: boolean;
  isDucked: boolean;
}

let engine: AmbientEngine | null = null;

// Frequencies in Hz for Fmaj7 -> Cmaj7 -> Dm9 -> Bbmaj7
const CHORD_PROGRESSION = [
  [174.61, 220.0, 261.63, 329.63], // Fmaj7
  [130.81, 196.0, 246.94, 329.63], // Cmaj7
  [146.83, 220.0, 261.63, 329.63], // Dm9
  [116.54, 174.61, 220.0, 293.66], // Bbmaj7
];

const MELODY_NOTES = [
  523.25, 659.25, 587.33, 440.0, 523.25, 698.46, 659.25, 587.33,
];

const NORMAL_VOLUME = 0.22;
const DUCKED_VOLUME = 0.03;

function initEngine(): AmbientEngine | null {
  if (typeof window === 'undefined') return null;
  if (engine) return engine;

  const AudioContextClass =
    window.AudioContext ||
    (window as unknown as { webkitAudioContext?: typeof AudioContext }).webkitAudioContext;
  if (!AudioContextClass) return null;

  const ctx = new AudioContextClass();
  const masterGain = ctx.createGain();
  masterGain.gain.setValueAtTime(0.0001, ctx.currentTime);

  const filter = ctx.createBiquadFilter();
  filter.type = 'lowpass';
  filter.frequency.setValueAtTime(980, ctx.currentTime);
  filter.Q.setValueAtTime(0.6, ctx.currentTime);

  // Dreamy soft delay echo for warm atmospheric tail
  const delay = ctx.createDelay(1.0);
  delay.delayTime.setValueAtTime(0.38, ctx.currentTime);
  const delayFeedback = ctx.createGain();
  delayFeedback.gain.setValueAtTime(0.28, ctx.currentTime);
  const delayWet = ctx.createGain();
  delayWet.gain.setValueAtTime(0.24, ctx.currentTime);

  filter.connect(masterGain);
  filter.connect(delay);
  delay.connect(delayFeedback);
  delayFeedback.connect(delay);
  delay.connect(delayWet);
  delayWet.connect(masterGain);

  masterGain.connect(ctx.destination);

  engine = {
    ctx,
    masterGain,
    filter,
    chordTimer: null,
    melodyTimer: null,
    isPlaying: false,
    isDucked: false,
  };

  return engine;
}

function playSoftPadChord(eng: AmbientEngine, freqs: number[]) {
  const now = eng.ctx.currentTime;
  freqs.forEach((freq) => {
    const osc = eng.ctx.createOscillator();
    const noteGain = eng.ctx.createGain();

    osc.type = 'sine';
    osc.frequency.setValueAtTime(freq, now);

    noteGain.gain.setValueAtTime(0.0001, now);
    noteGain.gain.linearRampToValueAtTime(0.085, now + 1.4);
    noteGain.gain.linearRampToValueAtTime(0.06, now + 3.2);
    noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 4.9);

    osc.connect(noteGain);
    noteGain.connect(eng.filter);

    osc.start(now);
    osc.stop(now + 5.0);
  });
}

function playMusicBoxNote(eng: AmbientEngine, freq: number) {
  const now = eng.ctx.currentTime;
  const osc = eng.ctx.createOscillator();
  const noteGain = eng.ctx.createGain();

  osc.type = 'triangle';
  osc.frequency.setValueAtTime(freq, now);

  noteGain.gain.setValueAtTime(0.0001, now);
  noteGain.gain.linearRampToValueAtTime(0.055, now + 0.06);
  noteGain.gain.exponentialRampToValueAtTime(0.0001, now + 1.9);

  osc.connect(noteGain);
  noteGain.connect(eng.filter);

  osc.start(now);
  osc.stop(now + 2.0);
}

export function startAmbientMusic(): boolean {
  const eng = initEngine();
  if (!eng) return false;

  if (eng.ctx.state === 'suspended') {
    eng.ctx.resume().catch(() => {});
  }

  if (eng.isPlaying) return true;
  eng.isPlaying = true;

  const targetVol = eng.isDucked ? DUCKED_VOLUME : NORMAL_VOLUME;
  const now = eng.ctx.currentTime;
  eng.masterGain.gain.cancelScheduledValues(now);
  eng.masterGain.gain.setValueAtTime(Math.max(eng.masterGain.gain.value, 0.0001), now);
  eng.masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.8);

  let chordIdx = 0;
  let melodyIdx = 0;

  playSoftPadChord(eng, CHORD_PROGRESSION[chordIdx]);
  playMusicBoxNote(eng, MELODY_NOTES[melodyIdx]);

  eng.chordTimer = window.setInterval(() => {
    if (!engine || !engine.isPlaying) return;
    chordIdx = (chordIdx + 1) % CHORD_PROGRESSION.length;
    playSoftPadChord(engine, CHORD_PROGRESSION[chordIdx]);
  }, 4600);

  eng.melodyTimer = window.setInterval(() => {
    if (!engine || !engine.isPlaying) return;
    melodyIdx = (melodyIdx + 1) % MELODY_NOTES.length;
    playMusicBoxNote(engine, MELODY_NOTES[melodyIdx]);
  }, 1550);

  return true;
}

export function stopAmbientMusic(): void {
  if (!engine) return;
  engine.isPlaying = false;

  if (engine.chordTimer !== null) {
    window.clearInterval(engine.chordTimer);
    engine.chordTimer = null;
  }
  if (engine.melodyTimer !== null) {
    window.clearInterval(engine.melodyTimer);
    engine.melodyTimer = null;
  }

  const now = engine.ctx.currentTime;
  engine.masterGain.gain.cancelScheduledValues(now);
  engine.masterGain.gain.setValueAtTime(engine.masterGain.gain.value, now);
  engine.masterGain.gain.linearRampToValueAtTime(0.0001, now + 0.45);
}

export function setAmbientMusicDucked(ducked: boolean): void {
  if (!engine) return;
  engine.isDucked = ducked;
  if (!engine.isPlaying) return;

  const targetVol = ducked ? DUCKED_VOLUME : NORMAL_VOLUME;
  const now = engine.ctx.currentTime;
  engine.masterGain.gain.cancelScheduledValues(now);
  engine.masterGain.gain.setValueAtTime(engine.masterGain.gain.value, now);
  engine.masterGain.gain.linearRampToValueAtTime(targetVol, now + 0.5);
}
