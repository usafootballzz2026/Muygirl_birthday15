import React from 'react';
import { motion } from 'motion/react';
import { Heart, Sparkles, RotateCcw } from 'lucide-react';

interface FinalSurpriseSectionProps {
  onSendHeartShower: () => void;
  onReplayAll: () => void;
}

export const FinalSurpriseSection: React.FC<FinalSurpriseSectionProps> = ({
  onSendHeartShower,
  onReplayAll,
}) => {
  return (
    <section id="forever" className="relative z-10 py-12 px-4 text-center">
      <motion.div
        initial={{ opacity: 0, y: 18 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true, margin: '-40px' }}
        transition={{ duration: 0.7 }}
        className="relative bg-gradient-to-b from-white/95 via-pink-50/90 to-purple-100/80 border border-pink-200 rounded-3xl px-5 py-10 shadow-[0_24px_60px_-16px_rgba(236,72,153,0.28)] overflow-hidden"
      >
        {/* Glowing layered heart centerpiece */}
        <div className="relative mx-auto mb-6 w-24 h-24 flex items-center justify-center">
          <div
            className="absolute inset-0 rounded-full bg-pink-400/30 blur-2xl animate-pulse"
            aria-hidden="true"
          />
          <div className="relative w-20 h-20 rounded-full bg-gradient-to-br from-pink-500 via-fuchsia-500 to-purple-600 flex items-center justify-center shadow-[0_0_34px_rgba(236,72,153,0.45)] animate-heartbeat-glow">
            <Heart className="w-10 h-10 text-white fill-white" />
          </div>
        </div>

        <h2 className="font-cursive text-4xl text-[#2B1537] mb-5 [text-wrap:balance]">
          Forever My Little Sister ❤️
        </h2>

        <div className="space-y-2 text-base text-[#4B2D5C] leading-relaxed mb-8">
          <p>No Matter Where Life Takes Us,</p>
          <p>You Will Always Have A Special Place In My Heart.</p>
          <p className="font-cursive text-3xl text-pink-600 pt-3">
            Once Again, Happy Birthday! 🎂
          </p>
        </div>

        <div className="flex flex-col gap-3">
          <button
            type="button"
            onClick={onSendHeartShower}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-gradient-to-r from-pink-500 to-purple-600 text-white font-semibold text-sm shadow-[0_12px_26px_-8px_rgba(236,72,153,0.5)] active:opacity-90 transition-opacity cursor-pointer"
          >
            <Sparkles className="w-4 h-4" />
            <span>Send Heart Shower ❤️</span>
          </button>

          <button
            type="button"
            onClick={onReplayAll}
            className="w-full min-h-[48px] inline-flex items-center justify-center gap-2 px-6 py-3.5 rounded-2xl bg-white border border-purple-200 text-purple-900 font-semibold text-sm active:bg-purple-50 transition-colors cursor-pointer"
          >
            <RotateCcw className="w-4 h-4" />
            <span>Replay Surprise</span>
          </button>
        </div>
      </motion.div>
    </section>
  );
};
