import React, { useEffect, useState } from 'react';
import { Cake } from 'lucide-react';

interface CountdownState {
  isBirthdayToday: boolean;
  days: number;
  hours: number;
  minutes: number;
  seconds: number;
}

function getNextBirthdayCountdown(): CountdownState {
  const now = new Date();
  const month = now.getMonth(); // 0-indexed: 10 = November
  const date = now.getDate();

  if (month === 10 && date === 15) {
    return {
      isBirthdayToday: true,
      days: 0,
      hours: 0,
      minutes: 0,
      seconds: 0,
    };
  }

  let targetYear = now.getFullYear();
  if (month > 10 || (month === 10 && date > 15)) {
    targetYear += 1;
  }

  const target = new Date(targetYear, 10, 15, 0, 0, 0, 0);
  const diffMs = Math.max(0, target.getTime() - now.getTime());

  const days = Math.floor(diffMs / (1000 * 60 * 60 * 24));
  const hours = Math.floor((diffMs % (1000 * 60 * 60 * 24)) / (1000 * 60 * 60));
  const minutes = Math.floor((diffMs % (1000 * 60 * 60)) / (1000 * 60));
  const seconds = Math.floor((diffMs % (1000 * 60)) / 1000);

  return {
    isBirthdayToday: false,
    days,
    hours,
    minutes,
    seconds,
  };
}

function pad2(n: number): string {
  return n.toString().padStart(2, '0');
}

export const BirthdayCountdown: React.FC = () => {
  const [countdown, setCountdown] = useState<CountdownState>(() =>
    getNextBirthdayCountdown()
  );

  useEffect(() => {
    const timer = window.setInterval(() => {
      setCountdown(getNextBirthdayCountdown());
    }, 1000);
    return () => window.clearInterval(timer);
  }, []);

  if (countdown.isBirthdayToday) {
    return (
      <div
        className="inline-flex items-center gap-1.5 text-xs font-semibold text-pink-600 whitespace-nowrap shrink-0"
        title="Happy Birthday — November 15!"
      >
        <Cake className="w-3.5 h-3.5 text-pink-500 shrink-0" />
        <span>Today · Nov 15 🎂</span>
      </div>
    );
  }

  const compactLabel =
    countdown.days > 0
      ? `${countdown.days}d ${pad2(countdown.hours)}h`
      : `${pad2(countdown.hours)}h ${pad2(countdown.minutes)}m`;

  const fullLabel =
    countdown.days > 0
      ? `${countdown.days}d ${pad2(countdown.hours)}h ${pad2(countdown.minutes)}m`
      : `${pad2(countdown.hours)}h ${pad2(countdown.minutes)}m ${pad2(countdown.seconds)}s`;

  return (
    <div
      className="inline-flex items-center gap-1.5 text-xs text-[#5B3D6B] whitespace-nowrap shrink-0"
      aria-label={`Countdown to November 15 birthday: ${fullLabel} remaining`}
    >
      <Cake className="w-3.5 h-3.5 text-pink-500 shrink-0" aria-hidden="true" />
      <span className="font-mono-tabular font-semibold text-[#2B1537] sm:hidden">
        {compactLabel}
      </span>
      <span className="hidden sm:inline font-mono-tabular font-semibold text-[#2B1537]">
        {fullLabel}
      </span>
      <span className="hidden lg:inline text-[#7E5B92]" aria-hidden="true">
        ·
      </span>
      <span className="hidden lg:inline text-[#7E5B92]">to Nov 15</span>
    </div>
  );
};
