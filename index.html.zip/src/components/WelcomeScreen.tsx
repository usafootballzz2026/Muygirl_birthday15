import React from 'react';
import { motion } from 'motion/react';
import { Heart, Gift } from 'lucide-react';

interface WelcomeScreenProps {
  onOpen: () => void;
}

export const WelcomeScreen: React.FC<WelcomeScreenProps> = ({ onOpen }) => {
  return (
    <section className="relative z-10 min-h-screen flex items-center justify-center px-6 py-16">
      {/* Soft luminous halo behind welcome centerpiece */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center"
        aria-hidden="true"
      >
        <div className="w-[340px] h-[340px] sm:w-[540px] sm:h-[540px] rounded-full bg-gradient-to-tr from-pink-300/35 via-purple-200/35 to-rose-200/30 blur-3xl animate-pulse" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 24 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.9, ease: [0.16, 1, 0.3, 1] }}
        className="relative max-w-2xl w-full text-center bg-white/80 backdrop-blur-md border border-pink-200/70 rounded-3xl px-8 py-12 sm:px-14 sm:py-16 shadow-[0_24px_64px_-18px_rgba(168,85,247,0.22)]"
      >
        {/* Delicate floral blossom SVG crown */}
        <motion.div
          initial={{ scale: 0.85, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.15, duration: 0.7 }}
          className="mx-auto mb-6 w-20 h-20 rounded-full bg-gradient-to-br from-pink-100 via-fuchsia-50 to-purple-100 border border-pink-200 flex items-center justify-center shadow-sm"
        >
          <Heart className="w-9 h-9 text-pink-500 fill-pink-500 animate-heartbeat-glow" />
        </motion.div>

        <p className="text-xs sm:text-sm font-medium tracking-wide text-purple-700/80 mb-4">
          Dedicated To My Dearest Sister · With Endless Love
        </p>

        <h1 className="font-cursive text-4xl sm:text-6xl leading-tight text-[#2B1537] mb-6 [text-wrap:balance]">
          A Special Surprise For Someone Special ❤️
        </h1>

        <p className="text-base sm:text-lg text-[#5B3D6B] leading-relaxed max-w-lg mx-auto mb-10">
          Every childhood laugh, every secret we kept, and every memory we share—wrapped into one little birthday journey just for you.
        </p>

        <motion.button
          type="button"
          onClick={onOpen}
          whileHover={{ scale: 1.03 }}
          whileTap={{ scale: 0.97 }}
          className="inline-flex items-center justify-center gap-3 px-8 py-4 rounded-2xl bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 text-white font-semibold text-base sm:text-lg shadow-[0_14px_30px_-8px_rgba(236,72,153,0.55)] hover:shadow-[0_18px_36px_-8px_rgba(147,51,234,0.55)] transition-all duration-200 focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-pink-500 cursor-pointer whitespace-nowrap"
        >
          <Gift className="w-5 h-5" />
          <span>Open Your Surprise 🎁</span>
        </motion.button>
      </motion.div>
    </section>
  );
};
