import React, { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Sparkles, ArrowRight, RotateCcw } from 'lucide-react';
import { playFunnyBoingSound, playVictoryFanfareSound } from '../utils/soundFx';

interface SecretLoginScreenProps {
  onUnlockSuccess: () => void;
}

export function isNovember15(rawInput: string): boolean {
  const cleaned = rawInput
    .trim()
    .toLowerCase()
    .replace(/,/g, ' ')
    .replace(/\s+/g, ' ')
    .replace(/\b(\d+)(st|nd|rd|th)\b/g, '$1');

  if (!cleaned) return false;

  // Formats like "15 november", "15 november 2026", "15 nov", "15 nov 2026"
  if (/^15 (nov|november)( \d{4})?$/.test(cleaned)) return true;

  // Formats like "november 15", "november 15 2026", "nov 15", "nov 15 2026"
  if (/^(nov|november) 15( \d{4})?$/.test(cleaned)) return true;

  // Numeric day-first formats like "15/11", "15-11", "15/11/2026", "15-11-2026"
  if (/^15[/-]11([/-]\d{2,4})?$/.test(cleaned)) return true;

  // ISO format like "2026-11-15"
  if (/^\d{4}[/-]11[/-]15$/.test(cleaned)) return true;

  return false;
}

export const SecretLoginScreen: React.FC<SecretLoginScreenProps> = ({
  onUnlockSuccess,
}) => {
  const [dateInput, setDateInput] = useState('');
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [shakeKey, setShakeKey] = useState(0);
  const [isUnlocked, setIsUnlocked] = useState(false);

  useEffect(() => {
    if (!isUnlocked) return;
    const timer = window.setTimeout(() => {
      onUnlockSuccess();
    }, 2300);
    return () => window.clearTimeout(timer);
  }, [isUnlocked, onUnlockSuccess]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (isUnlocked) return;

    const trimmed = dateInput.trim();
    if (!trimmed) {
      setErrorMsg('Please enter your special date first! 🎂');
      setShakeKey((k) => k + 1);
      playFunnyBoingSound(false);
      return;
    }

    if (isNovember15(trimmed)) {
      setErrorMsg(null);
      setIsUnlocked(true);
      playVictoryFanfareSound(false);
    } else {
      setErrorMsg('wrong_date');
      setShakeKey((k) => k + 1);
      playFunnyBoingSound(false);
    }
  };

  const handleRetry = () => {
    setDateInput('');
    setErrorMsg(null);
  };

  return (
    <section className="relative z-10 min-h-[100dvh] flex items-center justify-center px-4 pt-16 pb-8 bg-gradient-to-br from-[#FCE7F3] via-[#F3E8FF] to-[#E9D5FF]">
      {/* Soft luminous glow behind card */}
      <div
        className="pointer-events-none absolute inset-0 flex items-center justify-center"
        aria-hidden="true"
      >
        <div className="w-[300px] h-[300px] rounded-full bg-gradient-to-tr from-pink-300/45 via-fuchsia-200/35 to-purple-300/40 blur-3xl" />
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.75, ease: [0.16, 1, 0.3, 1] }}
        className="relative w-full max-w-md bg-white/90 backdrop-blur-lg border border-pink-200/80 rounded-3xl px-5 py-9 text-center shadow-[0_24px_64px_-16px_rgba(147,51,234,0.28)]"
      >
        {/* Animated Gift Box + Unlock Glowing Heart */}
        <div className="relative mx-auto mb-6 w-36 h-36 flex items-center justify-center">
          {/* Glowing aura when unlocked */}
          {isUnlocked && (
            <motion.div
              initial={{ scale: 0.5, opacity: 0 }}
              animate={{ scale: 1.35, opacity: 1 }}
              transition={{ duration: 0.7 }}
              className="absolute inset-0 rounded-full bg-gradient-to-tr from-pink-400/50 via-fuchsia-300/40 to-purple-400/50 blur-2xl"
              aria-hidden="true"
            />
          )}

          <motion.div
            key={shakeKey}
            animate={
              isUnlocked
                ? { scale: [1, 1.08, 1] }
                : shakeKey > 0
                ? { x: [-8, 8, -6, 6, -3, 3, 0] }
                : { y: [0, -7, 0] }
            }
            transition={
              isUnlocked
                ? { duration: 0.8, repeat: Infinity }
                : shakeKey > 0
                ? { duration: 0.4 }
                : { duration: 2.6, repeat: Infinity, ease: 'easeInOut' }
            }
            className="relative w-32 h-32 flex items-center justify-center"
          >
            {/* Glowing heart rising from the open gift box */}
            <AnimatePresence>
              {isUnlocked && (
                <motion.div
                  initial={{ y: 20, scale: 0.4, opacity: 0 }}
                  animate={{ y: -26, scale: 1.15, opacity: 1 }}
                  transition={{ duration: 0.65, ease: [0.16, 1, 0.3, 1] }}
                  className="absolute -top-3 z-20 flex flex-col items-center"
                >
                  <div className="w-16 h-16 rounded-full bg-gradient-to-br from-pink-500 to-purple-600 flex items-center justify-center shadow-[0_0_28px_rgba(236,72,153,0.75)] animate-heartbeat-glow">
                    <Heart className="w-8 h-8 text-white fill-white" />
                  </div>
                </motion.div>
              )}
            </AnimatePresence>

            {/* Custom 2D Animated Gift Box SVG */}
            <svg
              width="116"
              height="116"
              viewBox="0 0 120 120"
              fill="none"
              aria-label="Birthday Gift Box"
            >
              {/* Soft shadow */}
              <ellipse cx="60" cy="108" rx="38" ry="6" fill="#C084FC" fillOpacity="0.25" />

              {/* Gift box body */}
              <rect
                x="24"
                y="50"
                width="72"
                height="54"
                rx="10"
                fill="url(#giftBoxBody)"
                stroke="#F472B6"
                strokeWidth="2"
              />
              {/* Vertical ribbon */}
              <rect x="53" y="50" width="14" height="54" fill="#9333EA" fillOpacity="0.85" />

              {/* Animated Gift Box Lid */}
              <motion.g
                animate={
                  isUnlocked
                    ? { y: -22, x: -10, rotate: -18, opacity: 0.25 }
                    : { y: 0, x: 0, rotate: 0, opacity: 1 }
                }
                transition={{ duration: 0.55, ease: [0.16, 1, 0.3, 1] }}
                style={{ originX: '24px', originY: '50px' }}
              >
                <rect
                  x="18"
                  y="36"
                  width="84"
                  height="18"
                  rx="7"
                  fill="url(#giftBoxLid)"
                  stroke="#EC4899"
                  strokeWidth="2"
                />
                <rect x="53" y="36" width="14" height="18" fill="#7E22CE" />
                {/* Bow */}
                <path
                  d="M60 36 C48 20, 30 22, 36 34 C40 40, 52 38, 60 36 Z"
                  fill="#F43F5E"
                />
                <path
                  d="M60 36 C72 20, 90 22, 84 34 C80 40, 68 38, 60 36 Z"
                  fill="#EC4899"
                />
                <circle cx="60" cy="35" r="5.5" fill="#FDE047" />
              </motion.g>

              <defs>
                <linearGradient id="giftBoxBody" x1="24" y1="50" x2="96" y2="104" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#FBCFE8" />
                  <stop offset="1" stopColor="#F472B6" />
                </linearGradient>
                <linearGradient id="giftBoxLid" x1="18" y1="36" x2="102" y2="54" gradientUnits="userSpaceOnUse">
                  <stop stopColor="#F9A8D4" />
                  <stop offset="1" stopColor="#EC4899" />
                </linearGradient>
              </defs>
            </svg>
          </motion.div>
        </div>

        <AnimatePresence mode="wait">
          {!isUnlocked ? (
            <motion.div
              key="locked-form"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0, y: -8 }}
              transition={{ duration: 0.3 }}
            >
              <h1 className="font-cursive text-4xl sm:text-5xl text-[#2B1537] mb-2">
                Hey Princess! ❤️
              </h1>
              <p className="text-sm sm:text-base text-[#5B3D6B] mb-7">
                Your Special Surprise Is Waiting For You...
              </p>

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label htmlFor="special-date-input" className="sr-only">
                    Enter Your Special Date
                  </label>
                  <input
                    id="special-date-input"
                    type="text"
                    value={dateInput}
                    onChange={(e) => {
                      setDateInput(e.target.value);
                      if (errorMsg) setErrorMsg(null);
                    }}
                    placeholder="Enter Your Special Date 🎂"
                    autoComplete="off"
                    className="w-full px-5 py-4 rounded-2xl bg-white border-2 border-pink-200 focus:border-purple-500 focus:outline-none text-center text-base font-medium text-[#2B1537] placeholder:text-purple-400 shadow-inner transition-colors"
                  />
                </div>

                <motion.button
                  type="submit"
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                  className="w-full py-4 px-6 rounded-2xl bg-gradient-to-r from-pink-500 via-fuchsia-500 to-purple-600 text-white font-semibold text-base shadow-[0_14px_30px_-8px_rgba(236,72,153,0.55)] hover:opacity-95 transition-opacity flex items-center justify-center gap-2 cursor-pointer"
                >
                  <span>Enter</span>
                  <ArrowRight className="w-4 h-4" />
                </motion.button>
              </form>

              <AnimatePresence>
                {errorMsg && (
                  <motion.div
                    initial={{ opacity: 0, y: 6 }}
                    animate={{ opacity: 1, y: 0 }}
                    exit={{ opacity: 0 }}
                    className="mt-5 p-4 rounded-2xl bg-rose-50 border border-rose-200 text-rose-700 space-y-2"
                    role="alert"
                  >
                    {errorMsg === 'wrong_date' ? (
                      <div className="text-sm font-medium leading-relaxed">
                        <p>Oops! Wrong Date, Princess! 😂</p>
                        <p>Try Again, Your Surprise Is Waiting! ❤️</p>
                      </div>
                    ) : (
                      <p className="text-sm font-medium">{errorMsg}</p>
                    )}

                    <button
                      type="button"
                      onClick={handleRetry}
                      className="inline-flex items-center gap-1.5 text-xs font-semibold text-purple-800 hover:text-purple-950 underline underline-offset-2 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" />
                      <span>Clear &amp; Try Again</span>
                    </button>
                  </motion.div>
                )}
              </AnimatePresence>
            </motion.div>
          ) : (
            <motion.div
              key="unlocked-celebration"
              initial={{ opacity: 0, scale: 0.92 }}
              animate={{ opacity: 1, scale: 1 }}
              transition={{ duration: 0.45 }}
              className="py-3 space-y-5"
            >
              <div className="inline-flex items-center gap-2 text-xs font-semibold text-pink-600">
                <Sparkles className="w-4 h-4" />
                <span>November 15 Verified</span>
              </div>

              <h2 className="font-cursive text-3xl sm:text-5xl text-[#2B1537] leading-tight [text-wrap:balance]">
                Yayyy! You Unlocked Your Surprise! 🎁❤️
              </h2>

              <p className="text-sm text-[#5B3D6B]">
                Opening your birthday surprise...
              </p>

              <button
                type="button"
                onClick={onUnlockSuccess}
                className="inline-flex items-center gap-2 px-6 py-3 rounded-xl bg-gradient-to-r from-pink-500 to-purple-600 text-white text-sm font-semibold shadow-md hover:opacity-95 transition-opacity cursor-pointer"
              >
                <span>Enter Surprise Now</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            </motion.div>
          )}
        </AnimatePresence>
      </motion.div>
    </section>
  );
};
