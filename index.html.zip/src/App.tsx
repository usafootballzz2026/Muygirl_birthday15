/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useEffect, useRef, useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { Heart, Volume2, VolumeX } from 'lucide-react';
import { AmbientParticles } from './components/AmbientParticles';
import { BirthdayCountdown } from './components/BirthdayCountdown';
import { SecretLoginScreen } from './components/SecretLoginScreen';
import { BirthdayVideoSection } from './components/BirthdayVideoSection';
import { BirthdayLetterSection } from './components/BirthdayLetterSection';
import { MemoriesGallerySection } from './components/MemoriesGallerySection';
import { BeatBattleGame } from './components/BeatBattleGame';
import { FinalSurpriseSection } from './components/FinalSurpriseSection';
import {
  setAmbientMusicDucked,
  startAmbientMusic,
  stopAmbientMusic,
} from './utils/ambientMusic';

export default function App() {
  const [isAuthenticated, setIsAuthenticated] = useState(false);
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const [burstKey, setBurstKey] = useState(0);
  const [letterTrigger, setLetterTrigger] = useState(0);
  const letterRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    return () => {
      stopAmbientMusic();
    };
  }, []);

  const handleToggleMusic = () => {
    if (isMusicPlaying) {
      stopAmbientMusic();
      setIsMusicPlaying(false);
    } else {
      const started = startAmbientMusic();
      if (started) {
        setIsMusicPlaying(true);
      }
    }
  };

  const handleUnlockSuccess = () => {
    setBurstKey((k) => k + 1);
    setIsAuthenticated(true);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  const handleVideoEnded = () => {
    setLetterTrigger((t) => t + 1);
    if (letterRef.current) {
      letterRef.current.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  };

  const handleHeartShower = () => {
    setBurstKey((k) => k + 1);
  };

  const handleReplayAll = () => {
    setBurstKey((k) => k + 1);
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-[#FFF9FB] via-[#FCF4FA] to-[#F7EFFA] text-[#2B1537] relative">
      <AmbientParticles
        variant={isAuthenticated ? 'ambient' : 'login'}
        burstKey={burstKey}
      />

      <AnimatePresence mode="wait">
        {!isAuthenticated ? (
          <motion.div
            key="secret-login"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0, scale: 1.03 }}
            transition={{ duration: 0.6 }}
            className="relative"
          >
            {/* Subtle birthday countdown in top-left corner of Secret Login screen */}
            <div className="fixed top-3 left-3 z-50 px-3 py-2 rounded-full bg-white/90 backdrop-blur-md border border-pink-200/80 shadow-sm max-w-[calc(100vw-130px)]">
              <BirthdayCountdown />
            </div>

            {/* Floating ambient music toggle on Secret Login screen */}
            <div className="fixed top-3 right-3 z-50">
              <button
                type="button"
                onClick={handleToggleMusic}
                aria-pressed={isMusicPlaying}
                aria-label={
                  isMusicPlaying
                    ? 'Mute ambient background music'
                    : 'Play ambient relaxing background music'
                }
                className={`inline-flex items-center justify-center gap-1.5 min-h-[42px] px-3.5 py-2 rounded-full text-xs font-semibold backdrop-blur-md border transition-all duration-200 cursor-pointer whitespace-nowrap shadow-[0_8px_24px_-6px_rgba(147,51,234,0.3)] ${
                  isMusicPlaying
                    ? 'bg-gradient-to-r from-pink-500 to-purple-600 text-white border-pink-400'
                    : 'bg-white/90 text-[#2B1537] border-pink-200 hover:bg-pink-50'
                }`}
              >
                {isMusicPlaying ? (
                  <Volume2 className="w-4 h-4 shrink-0" />
                ) : (
                  <VolumeX className="w-4 h-4 shrink-0 text-purple-600" />
                )}
                <span>{isMusicPlaying ? 'On' : 'Music'}</span>
              </button>
            </div>

            <SecretLoginScreen onUnlockSuccess={handleUnlockSuccess} />
          </motion.div>
        ) : (
          <motion.div
            key="experience"
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.7 }}
            className="relative z-10 w-full overflow-x-hidden"
          >
            {/* Mobile-First App Top Bar (no desktop nav clutter) */}
            <header className="sticky top-0 z-40 bg-[#FFF9FB]/90 backdrop-blur-md border-b border-pink-200/60">
              <div className="max-w-md mx-auto px-3.5 h-14 flex items-center justify-between gap-2">
                <a
                  href="#video"
                  className="font-cursive text-2xl text-[#2B1537] whitespace-nowrap shrink-0"
                >
                  Forever Sister
                </a>

                <div className="flex items-center gap-2 shrink-0">
                  <BirthdayCountdown />

                  <button
                    type="button"
                    onClick={handleToggleMusic}
                    aria-pressed={isMusicPlaying}
                    aria-label={
                      isMusicPlaying
                        ? 'Mute ambient background music'
                        : 'Play ambient relaxing background music'
                    }
                    className={`inline-flex items-center justify-center w-10 h-10 rounded-full border transition-all duration-200 cursor-pointer shrink-0 shadow-sm ${
                      isMusicPlaying
                        ? 'bg-purple-100 text-purple-900 border-purple-300'
                        : 'bg-white text-[#5B3D6B] border-pink-200 hover:bg-pink-50'
                    }`}
                  >
                    {isMusicPlaying ? (
                      <Volume2 className="w-4 h-4 text-pink-600 shrink-0" />
                    ) : (
                      <VolumeX className="w-4 h-4 text-purple-500 shrink-0" />
                    )}
                  </button>

                  <button
                    type="button"
                    onClick={handleHeartShower}
                    aria-label="Send heart shower"
                    className="inline-flex items-center justify-center w-10 h-10 rounded-full bg-gradient-to-r from-pink-500 to-purple-600 text-white shadow-sm hover:opacity-95 transition-opacity cursor-pointer shrink-0"
                  >
                    <Heart className="w-4 h-4 fill-white" />
                  </button>
                </div>
              </div>
            </header>

            <main className="max-w-md mx-auto w-full">
              <BirthdayVideoSection
                onVideoEnded={handleVideoEnded}
                onPlaybackChange={setAmbientMusicDucked}
              />

              <div className="px-4">
                <div className="h-px bg-gradient-to-r from-transparent via-pink-200 to-transparent" />
              </div>

              <div ref={letterRef}>
                <BirthdayLetterSection revealTrigger={letterTrigger} />
              </div>

              <div className="px-4">
                <div className="h-px bg-gradient-to-r from-transparent via-purple-200 to-transparent" />
              </div>

              <MemoriesGallerySection />

              <div className="px-4">
                <div className="h-px bg-gradient-to-r from-transparent via-pink-200 to-transparent" />
              </div>

              <BeatBattleGame />

              <div className="px-4">
                <div className="h-px bg-gradient-to-r from-transparent via-purple-200 to-transparent" />
              </div>

              <FinalSurpriseSection
                onSendHeartShower={handleHeartShower}
                onReplayAll={handleReplayAll}
              />
            </main>

            <footer className="relative z-10 max-w-md mx-auto border-t border-pink-200/60 py-8 px-4 text-center text-xs text-[#6B4A7C]">
              Made with endless sisterly love · Happy Birthday ❤️
            </footer>
          </motion.div>
        )}
      </AnimatePresence>
    </div>
  );
}
